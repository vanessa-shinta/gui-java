/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Asus
 */
public class Kasir {
    String Nama;
    String Buku_ygdipinjam;
    String Hari;
    
    public Kasir(){
        this.Nama=" Masukkan Nama" ;
        this.Buku_ygdipinjam="Masukkan Judul Buku";
        this.Hari="Masukan hari peminjaman";
    }
    
    public Kasir(String nm, String hr, String buku){
        this.Nama=nm;
        this.Buku_ygdipinjam=buku;
        this.Hari=hr;
    }
            
    public String getNama(){
        return this.Nama;
        
    }
    public String getBuku_ygdipinjam(){
        return this.Buku_ygdipinjam;
        
    }
    public String getHari(){
        return this.Hari;
    }
    
}
